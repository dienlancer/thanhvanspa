<div class="pre-footer">
                <?php if(is_active_sidebar('bottom-content-widget')):?>
                        <?php dynamic_sidebar('bottom-content-widget')?>
    					<?php endif; ?>   
    </div>