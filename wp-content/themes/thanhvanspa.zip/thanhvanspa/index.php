<?php get_header();?>
<?php require_once "menu.php"; ?>
<?php get_footer(); ?>
<?php wp_footer();?>
</body>
</html>